// BubblingEffect.jsx
import React from 'react';
import { motion } from 'framer-motion';

const BubblingEffect = ({ x, y, point }) => {
    return (
        <motion.div
            initial={{ opacity: 1, y: 0 }}
            animate={{ opacity: 0, y: -150 }}
            transition={{ duration: 1 }}
            className='text-primary text-4xl'
            style={{
                position: 'absolute',
                left: x,
                top: y,
                pointerEvents: 'none',
                fontWeight: 'bold',
            }}
        >
            +{point}
        </motion.div>
    );
};

export default BubblingEffect;
